export {
  axisTop,
  axisRight,
  axisBottom,
  axisLeft
} from "./src/axis";
