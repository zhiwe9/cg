export default function() {
  return !this.node();
}
