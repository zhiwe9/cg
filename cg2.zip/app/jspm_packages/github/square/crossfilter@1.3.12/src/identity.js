function crossfilter_identity(d) {
  return d;
}
