/**
 * Created by yarden on 5/23/16.
 */
export default function(x) {
  return function() {
    return x;
  };
}
